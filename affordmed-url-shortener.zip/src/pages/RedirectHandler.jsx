import { useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { getLinkByCode, updateLink, removeExpiredLinks } from '../utils/storage.js'
import { logEvent, EVENTS } from '../utils/logger.js'

export default function RedirectHandler() {
  const { code } = useParams()
  const navigate = useNavigate()

  useEffect(() => {
    const now = Date.now()
    removeExpiredLinks(now)
    const record = getLinkByCode(code)
    if (!record) {
      alert('Link not found or expired.')
      navigate('/', { replace: true })
      return
    }

    if (record.expiry <= now) {
      alert('This short link has expired. Redirecting to home.')
      navigate('/', { replace: true })
      return
    }

    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Unknown'
    const click = {
      time: new Date().toISOString(),
      referrer: document.referrer || null,
      timezone,
      location: timezone, // storing timezone as "location" per requirements
    }
    const updated = { ...record, clicks: [...(record.clicks || []), click] }
    updateLink(updated)

    logEvent(EVENTS.URL_CLICKED, { code, shortUrl: record.shortUrl, referrer: click.referrer, timezone })

    // Perform redirect
    window.location.replace(record.longUrl)
  }, [code, navigate])

  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <div className="bg-white rounded-xl shadow p-6 text-center">
        <p className="text-gray-600">Redirecting…</p>
      </div>
    </div>
  )
}
