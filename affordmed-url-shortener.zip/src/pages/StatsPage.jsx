import { useEffect, useState } from 'react'
import { getAllLinks } from '../utils/storage.js'

function formatDT(msOrISO) {
  const d = typeof msOrISO === 'number' ? new Date(msOrISO) : new Date(msOrISO)
  return d.toLocaleString()
}

export default function StatsPage() {
  const [links, setLinks] = useState([])

  useEffect(() => {
    setLinks(getAllLinks().sort((a,b) => b.createdAt - a.createdAt))
  }, [])

  if (!links.length) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-10">
        <div className="bg-white border rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-2">Statistics</h2>
          <p className="text-gray-600">No links yet. Create some on the Home page.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <div className="bg-white border rounded-xl p-6">
        <h2 className="text-xl font-semibold mb-4">All Shortened Links</h2>
        <div className="space-y-6">
          {links.map(link => (
            <div key={link.code} className="border rounded-lg p-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div className="space-y-1">
                  <div className="text-sm"><span className="font-medium">Short URL:</span> <a className="text-blue-600 hover:underline" href={link.shortUrl} target="_blank" rel="noreferrer">{link.shortUrl}</a></div>
                  <div className="text-sm break-all"><span className="font-medium">Original:</span> {link.longUrl}</div>
                </div>
                <div className="text-sm text-gray-600">
                  <div>Created: {formatDT(link.createdAt)}</div>
                  <div>Expires: {formatDT(link.expiry)}</div>
                  <div>Clicks: <span className="font-semibold">{(link.clicks || []).length}</span></div>
                </div>
              </div>

              {(link.clicks && link.clicks.length > 0) && (
                <div className="mt-4">
                  <h4 className="font-medium mb-2">Click Logs</h4>
                  <ul className="divide-y">
                    {link.clicks.map((c, i) => (
                      <li key={i} className="py-2 text-sm text-gray-700">
                        <div className="flex flex-wrap gap-x-6 gap-y-1">
                          <span><span className="text-gray-500">Time:</span> {formatDT(c.time)}</span>
                          <span><span className="text-gray-500">Referrer:</span> {c.referrer || 'Direct'}</span>
                          <span><span className="text-gray-500">Location:</span> {c.location || c.timezone || 'Unknown'}</span>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
