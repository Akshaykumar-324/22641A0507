import { useState } from 'react'
import { nanoid } from 'nanoid'
import { saveLink } from '../utils/storage.js'
import { logEvent, EVENTS } from '../utils/logger.js'

const DEFAULT_EXP_MINUTES = 30

function isValidUrl(str) {
  try {
    const u = new URL(str)
    return u.protocol === 'http:' || u.protocol === 'https:'
  } catch {
    return false
  }
}

export default function ShortenerPage() {
  const [urls, setUrls] = useState([''])
  const [error, setError] = useState(null)
  const maxInputs = 5

  const addInput = () => {
    if (urls.length < maxInputs) {
      setUrls([...urls, ''])
    }
  }

  const updateUrl = (idx, val) => {
    const next = [...urls]
    next[idx] = val
    setUrls(next)
  }

  const removeInput = (idx) => {
    const next = urls.filter((_, i) => i !== idx)
    setUrls(next.length ? next : [''])
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setError(null)

    const trimmed = urls.map(u => u.trim()).filter(Boolean)
    if (!trimmed.length) {
      setError('Please enter at least one URL.')
      return
    }
    if (trimmed.length > maxInputs) {
      setError('You can only shorten up to 5 URLs at a time.')
      return
    }

    const invalid = trimmed.filter(u => !isValidUrl(u))
    if (invalid.length) {
      setError('One or more URLs are invalid. Please fix them.')
      return
    }

    const now = Date.now()
    const expiry = now + DEFAULT_EXP_MINUTES * 60 * 1000

    const created = trimmed.map(longUrl => {
      const code = nanoid(6)
      const base = window.location.origin
      const shortUrl = `${base}/${code}`
      const link = {
        code,
        shortUrl,
        longUrl,
        createdAt: now,
        expiry,
        clicks: [], // {time, referrer, timezone}
      }
      saveLink(link)
      logEvent(EVENTS.URL_SHORTENED, { code, shortUrl, longUrl })
      return link
    })

    // Reset form
    setUrls([''])

    alert(`Shortened ${created.length} link(s). You can find them on the Statistics page.`)
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <div className="max-w-xl mx-auto bg-white shadow rounded-xl p-6">
        <h1 className="text-2xl font-semibold mb-4">Shorten your URLs</h1>
        <p className="text-sm text-gray-600 mb-6">Enter up to 5 URLs to shorten. Links expire in {DEFAULT_EXP_MINUTES} minutes.</p>
        <form onSubmit={handleSubmit} className="space-y-3">
          {urls.map((u, idx) => (
            <div key={idx} className="flex gap-2">
              <input
                type="url"
                required
                value={u}
                onChange={(e) => updateUrl(idx, e.target.value)}
                placeholder="https://example.com/very/long/link"
                className="flex-1 border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              {urls.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeInput(idx)}
                  className="px-3 py-2 border rounded-lg hover:bg-gray-50"
                  aria-label="Remove URL input"
                >
                  ✕
                </button>
              )}
            </div>
          ))}
          <div className="flex items-center gap-3 pt-2">
            <button
              type="button"
              onClick={addInput}
              disabled={urls.length >= maxInputs}
              className="px-3 py-2 border rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              + Add URL
            </button>
            <button
              type="submit"
              className="ml-auto px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium"
            >
              Shorten
            </button>
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
        </form>
      </div>
    </div>
  )
}
