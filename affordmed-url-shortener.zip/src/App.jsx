import { Routes, Route, Link } from 'react-router-dom'
import ShortenerPage from './pages/ShortenerPage.jsx'
import RedirectHandler from './pages/RedirectHandler.jsx'
import StatsPage from './pages/StatsPage.jsx'

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <nav className="bg-white border-b">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="text-xl font-semibold">AffordMed URL Shortener</Link>
            <div className="space-x-4">
              <Link to="/" className="text-gray-700 hover:text-black">Home</Link>
              <Link to="/stats" className="text-gray-700 hover:text-black">Statistics</Link>
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-1">
        <Routes>
          <Route path="/" element={<ShortenerPage />} />
          <Route path="/stats" element={<StatsPage />} />
          <Route path="/:code" element={<RedirectHandler />} />
        </Routes>
      </main>

      <footer className="py-6 text-center text-sm text-gray-500">
        <span>&copy; {new Date().getFullYear()} AffordMed</span>
      </footer>
    </div>
  )
}
