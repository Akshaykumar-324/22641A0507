// Frontend-only logging to sessionStorage
// Events: URL_SHORTENED, URL_CLICKED
export const EVENTS = {
  URL_SHORTENED: 'URL_SHORTENED',
  URL_CLICKED: 'URL_CLICKED',
};

export function logEvent(type, payload = {}) {
  try {
    const key = 'affordmed__event_logs';
    const logs = JSON.parse(sessionStorage.getItem(key) || '[]');
    logs.push({
      id: crypto.randomUUID ? crypto.randomUUID() : String(Math.random()),
      type,
      payload,
      at: new Date().toISOString(),
    });
    sessionStorage.setItem(key, JSON.stringify(logs));
  } catch (e) {
    // no-op if sessionStorage is blocked
    console.warn('Logging failed:', e);
  }
}

export function getEventLogs() {
  try {
    return JSON.parse(sessionStorage.getItem('affordmed__event_logs') || '[]');
  } catch {
    return [];
  }
}
