// Simple helpers for localStorage
const LINKS_KEY = 'affordmed__links';

export function getAllLinks() {
  try {
    const raw = localStorage.getItem(LINKS_KEY);
    const list = raw ? JSON.parse(raw) : [];
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

export function saveAllLinks(list) {
  localStorage.setItem(LINKS_KEY, JSON.stringify(list));
}

export function saveLink(link) {
  const list = getAllLinks();
  list.push(link);
  saveAllLinks(list);
}

export function getLinkByCode(code) {
  const list = getAllLinks();
  return list.find(l => l.code === code);
}

export function updateLink(updated) {
  const list = getAllLinks();
  const idx = list.findIndex(l => l.code === updated.code);
  if (idx !== -1) {
    list[idx] = updated;
    saveAllLinks(list);
  }
}

export function removeExpiredLinks(now = Date.now()) {
  const list = getAllLinks();
  const filtered = list.filter(l => (l.expiry > now));
  if (filtered.length !== list.length) saveAllLinks(filtered);
}

export function clearAll() {
  localStorage.removeItem(LINKS_KEY);
}
