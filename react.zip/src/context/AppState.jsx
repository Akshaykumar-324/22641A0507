import React from "react"
import { createLogger } from "../lib/logger"
import { saveState, loadState } from "../lib/storage"

export const AppContext = React.createContext()

const initial = loadState() || { urls: {} }

function reducer(state, action) {
  switch (action.type) {
    case "ADD_URL": {
      const { url, code } = action.payload
      const gen = code || Math.random().toString(36).substr(2, 6)
      if (state.urls[gen]) {
        alert("Code already exists")
        return state
      }
      const newUrls = {
        ...state.urls,
        [gen]: {
          code: gen,
          original: url,
          expiry: Date.now() + 30 * 60 * 1000,
          clicks: []
        }
      }
      const newState = { urls: newUrls }
      saveState(newState)
      return newState
    }
    case "CLICK": {
      const { code } = action.payload
      const entry = state.urls[code]
      if (!entry) return state
      entry.clicks.push({ time: Date.now() })
      const newUrls = { ...state.urls, [code]: entry }
      const newState = { urls: newUrls }
      saveState(newState)
      return newState
    }
    default:
      return state
  }
}

const logger = createLogger()

function applyMiddleware(dispatch) {
  return (action) => {
    logger.log("ACTION", action)
    return dispatch(action)
  }
}

export function AppProvider({ children }) {
  const [state, baseDispatch] = React.useReducer(reducer, initial)
  const dispatch = React.useMemo(() => applyMiddleware(baseDispatch), [])
  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  )
}