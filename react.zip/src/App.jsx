import React from "react"
import { Routes, Route, Link } from "react-router-dom"
import ShortenerPage from "./pages/ShortenerPage"
import StatsPage from "./pages/StatsPage"
import RedirectPage from "./pages/RedirectPage"
import { AppBar, Toolbar, Button, Container } from "@mui/material"

export default function App() {
  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <Button color="inherit" component={Link} to="/">Shortener</Button>
          <Button color="inherit" component={Link} to="/stats">Statistics</Button>
        </Toolbar>
      </AppBar>
      <Container sx={{ mt: 4 }}>
        <Routes>
          <Route path="/" element={<ShortenerPage />} />
          <Route path="/stats" element={<StatsPage />} />
          <Route path="/r/:code" element={<RedirectPage />} />
        </Routes>
      </Container>
    </>
  )
}