import React, { useState, useContext } from "react"
import { TextField, Button, Stack } from "@mui/material"
import { AppContext } from "../context/AppState"

export function UrlForm() {
  const { dispatch } = useContext(AppContext)
  const [url, setUrl] = useState("")
  const [code, setCode] = useState("")

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!url.startsWith("http")) {
      alert("Invalid URL, must start with http")
      return
    }
    dispatch({ type: "ADD_URL", payload: { url, code } })
    setUrl("")
    setCode("")
  }

  return (
    <form onSubmit={handleSubmit}>
      <Stack spacing={2} direction="row">
        <TextField
          label="Original URL"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          fullWidth
          required
        />
        <TextField
          label="Custom Code (optional)"
          value={code}
          onChange={(e) => setCode(e.target.value)}
        />
        <Button type="submit" variant="contained">
          Shorten
        </Button>
      </Stack>
    </form>
  )
}