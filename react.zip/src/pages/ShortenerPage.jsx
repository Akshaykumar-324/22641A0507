import React, { useContext } from "react"
import { UrlForm } from "../components/UrlForm"
import { AppContext } from "../context/AppState"
import { Typography } from "@mui/material"

export default function ShortenerPage() {
  const { state } = useContext(AppContext)

  return (
    <div>
      <Typography variant="h5" gutterBottom>
        URL Shortener
      </Typography>
      <UrlForm />
      <div style={{ marginTop: "20px" }}>
        {Object.values(state.urls).map((url) => (
          <div key={url.code}>
            <b>{url.code}</b> → {url.original} (valid till{" "}
            {new Date(url.expiry).toLocaleString()})
          </div>
        ))}
      </div>
    </div>
  )
}