import React, { useContext, useEffect } from "react"
import { useParams } from "react-router-dom"
import { AppContext } from "../context/AppState"

export default function RedirectPage() {
  const { code } = useParams()
  const { state, dispatch } = useContext(AppContext)

  useEffect(() => {
    const entry = state.urls[code]
    if (!entry) {
      alert("Code not found")
      return
    }
    if (Date.now() > entry.expiry) {
      alert("This link expired")
      return
    }
    dispatch({ type: "CLICK", payload: { code } })
    window.location.href = entry.original
  }, [code, state, dispatch])

  return <p>Redirecting...</p>
}