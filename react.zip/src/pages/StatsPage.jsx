import React, { useContext } from "react"
import { AppContext } from "../context/AppState"
import { Typography } from "@mui/material"

export default function StatsPage() {
  const { state } = useContext(AppContext)

  return (
    <div>
      <Typography variant="h5" gutterBottom>
        URL Statistics
      </Typography>
      {Object.values(state.urls).map((url) => (
        <div key={url.code}>
          <b>{url.code}</b> → {url.original} | Clicks: {url.clicks.length}
        </div>
      ))}
    </div>
  )
}